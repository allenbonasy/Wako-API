﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DTransAPI.Models
{
    public class Sub_Post
    {
        public int Id { get; set; }
      
        public String PostID { get; set; }
        public  String payeeID { get; set; }
    
    }
}