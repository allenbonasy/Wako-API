﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DTransAPI.Models
{
    public class SubscriberModel
    {

        public string agentId { get; set; }

        public string firstName { get; set; }

        public string client { get; set; }

        public string lastName { get; set; }

        public string idNumber { get; set; }

        public string referenceId { get; set; }

        public string result { get; set; }
    }
}