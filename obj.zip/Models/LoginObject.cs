﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DTransAPI.Models
{
    public class LoginObject
    {
        public String email { get; set; }
       public String password { get; set; }
    }
}